"use strict";

(function exposeNetworkExporterShared(global) {
  const SENSITIVE_HEADER_NAMES = new Set([
    "authorization",
    "cookie",
    "set-cookie",
    "x-api-key",
    "x-auth-token",
    "x-csrf-token",
    "xsrf-token"
  ]);

  const MAX_EXPORT_BODY_BYTES = 256 * 1024;
  const MAX_STORED_BODY_BYTES = 5 * 1024 * 1024;

  const BINARY_MIME_PREFIXES = [
    "image/",
    "font/",
    "audio/",
    "video/",
    "application/octet-stream",
    "application/wasm",
    "application/zip",
    "application/gzip",
    "application/x-gzip",
    "application/x-bzip",
    "application/x-bzip2",
    "application/x-tar",
    "application/x-7z-compressed",
    "application/x-rar-compressed",
    "application/pdf"
  ];

  function isLikelyBinaryMimeType(mimeType) {
    const mime = String(mimeType || "").toLowerCase();
    if (!mime) {
      return false;
    }
    return BINARY_MIME_PREFIXES.some((prefix) => mime.startsWith(prefix));
  }

  function getByteLengthLocal(text) {
    if (!text) {
      return 0;
    }
    return new TextEncoder().encode(text).length;
  }

  function truncateBody(text, maxBytes) {
    const limit = Number.isFinite(maxBytes) && maxBytes > 0 ? maxBytes : MAX_EXPORT_BODY_BYTES;
    const value = text == null ? "" : String(text);
    const byteLength = getByteLengthLocal(value);
    if (byteLength <= limit) {
      return value;
    }

    const encoder = new TextEncoder();
    const decoder = new TextDecoder("utf-8", { fatal: false });
    const bytes = encoder.encode(value);
    const sliced = bytes.subarray(0, limit);
    const decoded = decoder.decode(sliced, { stream: true });
    return `${decoded}\n... [truncated, original ${byteLength.toLocaleString()} bytes]`;
  }

  function clampStoredBody(text) {
    const value = text == null ? "" : String(text);
    const byteLength = getByteLengthLocal(value);
    if (byteLength <= MAX_STORED_BODY_BYTES) {
      return value;
    }
    return truncateBody(value, MAX_STORED_BODY_BYTES);
  }

  // ---- Persisted panel settings -------------------------------------------
  // Mirrors Chrome DevTools' settings model: long-lived user preferences are
  // persisted per profile, while task state (recording, selection, requests)
  // stays session-only.
  const PERSISTED_SETTINGS_KEY = "networkExporter.settings.v1";
  const PERSISTED_FILTER_TEXT_MAX_LENGTH = 1000;
  const PERSISTED_TYPE_GROUPS = new Set([
    "all",
    "fetch-xhr",
    "doc",
    "css",
    "js",
    "font",
    "img",
    "media",
    "manifest",
    "socket",
    "wasm",
    "other"
  ]);
  const PERSISTED_STATUS_FILTERS = new Set(["", "2", "3", "4", "5", "failed", "errors"]);
  const PERSISTED_EXPORT_FIELDS = new Set([
    "curlRequest",
    "statusCode",
    "responseBody",
    "method",
    "url",
    "name",
    "type",
    "size",
    "time",
    "initiator",
    "requestHeaders",
    "requestBody",
    "responseHeaders",
    "mimeType"
  ]);
  const DEFAULT_PERSISTED_EXPORT_FIELDS = ["curlRequest", "statusCode", "responseBody", "method"];

  function getPersistedSettingsDefaults() {
    return {
      preserveLog: false,
      invertFilter: false,
      excludeExtensionRequests: true,
      filterText: "",
      activeType: "all",
      statusFilter: "",
      isExportCollapsed: false,
      exportFields: DEFAULT_PERSISTED_EXPORT_FIELDS.slice(),
      truncateLargeBodies: true
    };
  }

  function sanitizePersistedSettings(raw) {
    const settings = getPersistedSettingsDefaults();
    if (!raw || typeof raw !== "object") {
      return settings;
    }

    for (const key of [
      "preserveLog",
      "invertFilter",
      "excludeExtensionRequests",
      "isExportCollapsed",
      "truncateLargeBodies"
    ]) {
      if (typeof raw[key] === "boolean") {
        settings[key] = raw[key];
      }
    }

    if (typeof raw.filterText === "string") {
      settings.filterText = raw.filterText.slice(0, PERSISTED_FILTER_TEXT_MAX_LENGTH);
    }

    if (typeof raw.activeType === "string" && PERSISTED_TYPE_GROUPS.has(raw.activeType)) {
      settings.activeType = raw.activeType;
    }

    if (typeof raw.statusFilter === "string" && PERSISTED_STATUS_FILTERS.has(raw.statusFilter)) {
      settings.statusFilter = raw.statusFilter;
    }

    if (Array.isArray(raw.exportFields)) {
      const seen = new Set();
      const exportFields = [];
      for (const field of raw.exportFields) {
        if (typeof field === "string" && PERSISTED_EXPORT_FIELDS.has(field) && !seen.has(field)) {
          seen.add(field);
          exportFields.push(field);
        }
      }
      if (exportFields.length) {
        settings.exportFields = exportFields;
      }
    }

    return settings;
  }

  function loadPersistedSettings(storage) {
    let raw = null;
    try {
      const text = storage?.getItem?.(PERSISTED_SETTINGS_KEY);
      if (typeof text === "string" && text) {
        raw = JSON.parse(text);
      }
    } catch {
      raw = null;
    }
    return sanitizePersistedSettings(raw);
  }

  function persistSettings(storage, settings) {
    try {
      const merged = { ...loadPersistedSettings(storage), ...(settings || {}) };
      storage?.setItem?.(PERSISTED_SETTINGS_KEY, JSON.stringify(merged));
    } catch {
      // Storage unavailable (disabled or quota exceeded) — keep in-memory state only.
    }
  }

  function createRequestNormalizer() {
    let nextRequestSequence = 0;

    function normalizeRequest(entry) {
      const request = entry.request || {};
      const response = entry.response || {};
      const timings = entry.timings || {};
      const url = request.url || "";
      const method = request.method || "";
      const status = Number.isFinite(response.status) ? response.status : null;
      const time = typeof entry.time === "number" ? entry.time : sumTimings(timings);
      const startedDateTime = entry.startedDateTime || "";
      const resourceType = getResourceType(entry);

      return {
        id: makeRequestId(entry),
        name: getName(url),
        url,
        method,
        statusCode: status,
        statusText: response.statusText || "",
        type: resourceType,
        typeGroup: getTypeGroup(resourceType, response.content?.mimeType || ""),
        mimeType: response.content?.mimeType || "",
        sizeBytes: getSizeBytes(entry),
        timeMs: Number.isFinite(time) ? time : null,
        initiator: getInitiator(entry),
        startedDateTime,
        requestHeaders: normalizeHeaders(request.headers || []),
        responseHeaders: normalizeHeaders(response.headers || []),
        requestBody: request.postData?.text || "",
        responseBody: response.content?.text || "",
        responseEncoding: response.content?.encoding || ""
      };
    }

    function makeRequestId(entry) {
      if (entry._requestId) {
        return `chrome:${entry._requestId}`;
      }

      const request = entry.request || {};
      const response = entry.response || {};
      const started = entry.startedDateTime || "";
      const signature = [
        started,
        request.method || "",
        request.url || "",
        response.status || "",
        entry.time || ""
      ].join("|");
      nextRequestSequence += 1;
      return `fallback:${nextRequestSequence}:${signature}`;
    }

    return {
      normalizeRequest
    };
  }

  function getName(url) {
    if (!url) {
      return "(unknown)";
    }

    try {
      const parsed = new URL(url);
      const lastPath = parsed.pathname.split("/").filter(Boolean).pop();
      return lastPath ? `${lastPath}${parsed.search}` : parsed.hostname;
    } catch {
      return url;
    }
  }

  function getResourceType(entry) {
    const rawType = entry._resourceType || entry.type || entry.resourceType || "";
    if (rawType) {
      return String(rawType).toLowerCase();
    }

    const mimeType = entry.response?.content?.mimeType || "";
    return guessTypeFromMime(mimeType);
  }

  function guessTypeFromMime(mimeType) {
    const mime = mimeType.toLowerCase();
    if (mime.includes("html")) return "document";
    if (mime.includes("css")) return "stylesheet";
    if (mime.includes("javascript") || mime.includes("ecmascript")) return "script";
    if (mime.startsWith("image/")) return "image";
    if (mime.startsWith("font/")) return "font";
    if (mime.startsWith("audio/") || mime.startsWith("video/")) return "media";
    if (mime.includes("manifest")) return "manifest";
    if (mime.includes("wasm")) return "wasm";
    if (mime.includes("json") || mime.includes("xml")) return "fetch";
    return "other";
  }

  function getTypeGroup(type, mimeType) {
    const normalized = String(type || "").toLowerCase();
    if (["xhr", "fetch"].includes(normalized)) return "fetch-xhr";
    if (["document", "doc"].includes(normalized)) return "doc";
    if (["stylesheet", "css"].includes(normalized)) return "css";
    if (["script", "js"].includes(normalized)) return "js";
    if (["font"].includes(normalized)) return "font";
    if (["image", "img"].includes(normalized)) return "img";
    if (["media", "audio", "video"].includes(normalized)) return "media";
    if (["manifest"].includes(normalized)) return "manifest";
    if (["websocket", "socket", "webtransport"].includes(normalized)) return "socket";
    if (["wasm"].includes(normalized)) return "wasm";

    const guessed = guessTypeFromMime(mimeType);
    if (guessed === "document") return "doc";
    if (guessed === "stylesheet") return "css";
    if (guessed === "script") return "js";
    if (guessed === "image") return "img";
    if (guessed === "fetch") return "fetch-xhr";
    if (["font", "media", "manifest", "wasm"].includes(guessed)) return guessed;
    return "other";
  }

  function getSizeBytes(entry) {
    const response = entry.response || {};
    const bodySize = Number(response.bodySize);
    const headersSize = Number(response.headersSize);
    const contentSize = Number(response.content?.size);

    if (Number.isFinite(bodySize) && bodySize >= 0) {
      return bodySize + (Number.isFinite(headersSize) && headersSize > 0 ? headersSize : 0);
    }
    if (Number.isFinite(contentSize) && contentSize >= 0) {
      return contentSize;
    }
    return null;
  }

  function getInitiator(entry) {
    const initiator = entry._initiator || entry.initiator;
    if (!initiator) {
      return "";
    }
    if (typeof initiator === "string") {
      return initiator;
    }
    if (initiator.url) {
      const line = initiator.lineNumber != null ? `:${initiator.lineNumber}` : "";
      return `${getName(initiator.url)}${line}`;
    }
    if (initiator.stack?.callFrames?.length) {
      const frame = initiator.stack.callFrames[0];
      const line = frame.lineNumber != null ? `:${frame.lineNumber}` : "";
      return `${getName(frame.url || frame.functionName || "script")}${line}`;
    }
    return initiator.type || "";
  }

  function normalizeHeaders(headers) {
    return headers.map((header) => ({
      name: header.name || "",
      value: header.value || ""
    }));
  }

  function sumTimings(timings) {
    const values = Object.values(timings || {}).filter((value) => Number.isFinite(value) && value > 0);
    return values.length ? values.reduce((total, value) => total + value, 0) : null;
  }

  const TOKEN_SPLIT_REGEX = /[^\s,{}()\[\]:;"'`]+|[\s,{}()\[\]:;"'`]/g;

  function getByteLength(text) {
    if (!text) {
      return 0;
    }
    return new TextEncoder().encode(text).length;
  }

  function estimateTokens(text) {
    if (!text) {
      return 0;
    }

    let count = 0;
    const tokens = text.match(TOKEN_SPLIT_REGEX) || [];
    for (const token of tokens) {
      if (/^\s+$/.test(token)) {
        continue;
      }
      count += token.length <= 4 ? 1 : Math.ceil(token.length / 4);
    }
    return count;
  }

  function isFailedRequest(request) {
    const statusCode = Number(request.statusCode);
    return !Number.isFinite(statusCode) || statusCode < 100;
  }

  function isClientErrorRequest(request) {
    const statusCode = Number(request.statusCode);
    return Number.isFinite(statusCode) && statusCode >= 400 && statusCode < 500;
  }

  function isServerErrorRequest(request) {
    const statusCode = Number(request.statusCode);
    return Number.isFinite(statusCode) && statusCode >= 500;
  }

  function isErrorRequest(request) {
    return isClientErrorRequest(request) || isServerErrorRequest(request) || isFailedRequest(request);
  }

  global.NetworkExporterShared = {
    SENSITIVE_HEADER_NAMES,
    MAX_EXPORT_BODY_BYTES,
    MAX_STORED_BODY_BYTES,
    PERSISTED_SETTINGS_KEY,
    getPersistedSettingsDefaults,
    loadPersistedSettings,
    persistSettings,
    createRequestNormalizer,
    getName,
    getTypeGroup,
    getByteLength,
    estimateTokens,
    isFailedRequest,
    isClientErrorRequest,
    isServerErrorRequest,
    isErrorRequest,
    isLikelyBinaryMimeType,
    truncateBody,
    clampStoredBody
  };
})(globalThis);
